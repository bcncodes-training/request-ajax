### Ejercicio AJAX

A partir de la página web proporcionada, añadir el código JavaScript necesario para que:

- Al cargar la página, el cuadro de texto debe mostrar por defecto la URL de la propia página.
- Al pulsar el botón "Mostrar Contenidos", se debe descargar mediante peticiones AJAX el contenido correspondiente a la URL introducida por el usuario. El contenido de la respuesta recibida del servidor se debe mostrar en la zona de "Contenidos del archivo".
- En la zona "Estados de la petición" se debe mostrar en todo momento el estado en el que se encuentra la petición (No inicializada, cargando, completada, etc.)
- Mostrar el contenido de todas las cabeceras de la respuesta del servidor en la zona "Cabeceras HTTP de la respuesta del servidor".
- Mostrar el código y texto de estado de la respuesta del servidor en la zona "Código de estado".
